// ==UserScript==
// @name         Youtube RSS feed URL
// @version      0.1
// @match       *://www.youtube.com/*
// @match       *://youtube.com/*
// @description  Returns youtube channel RSS URL
// ==/UserScript==

(function() {
    'use strict';
    for (var arrScripts = document.getElementsByTagName('script'), i = 0; i < arrScripts.length; i++) {
        if (arrScripts[i].textContent.indexOf('channelId') != -1) {
            var channelId = arrScripts[i].textContent.match(/\"channelId\"\s*\:\s*\"(.*?)\"/)[1];
            var channelRss = 'https://www.youtube.com/feeds/videos.xml?channel_id=' + channelId;
            var channelTitle = document.title.match(/\(?\d*\)?\s?(.*?)\s\-\sYouTube/)[1];
            console.log('The rss feed of the channel \'' + channelTitle + '\' is:\n' + channelRss);
            alert('The rss feed of the channel \'' + channelTitle + '\' is:\n' + channelRss);
            break;
        }
    }
})();