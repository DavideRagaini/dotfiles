// ==UserScript==
// @name           Yewtube redirector
// @namespace      mamg22's userscripts
// @match          http://www.youtube.com/*
// @match          https://www.youtube.com/*
// @match          http://youtube.com/*
// @match          https://youtube.com/*
// @run-at         document-start
// ==/UserScript==
location.host="yewtu.be";