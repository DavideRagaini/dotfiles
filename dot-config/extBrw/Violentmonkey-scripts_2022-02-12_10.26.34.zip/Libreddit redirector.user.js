// ==UserScript==
// @name           Libreddit redirector
// @namespace      raghyz's userscripts
// @match          http://www.reddit.com/*
// @match          https://www.reddit.com/*
// @match          http://reddit.com/*
// @match          https://reddit.com/*
// @run-at         document-start
// ==/UserScript==
location.host = "r.nf";
